import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../App';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useContext(AuthContext);

  const submit = async (e) => {
    e.preventDefault();
    try {
      await login(email, password);
      alert('Logged in (scaffold)');
    } catch (err) { console.error(err); alert('Login failed'); }
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Login</h2>
      <form onSubmit={submit} className="space-y-2">
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}
