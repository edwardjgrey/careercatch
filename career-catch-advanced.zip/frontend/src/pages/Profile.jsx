import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Profile() {
  const raw = localStorage.getItem('career_catch_user');
  const user = raw ? JSON.parse(raw) : null;
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    (async () => {
      if (!user) return;
      try {
        const base = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
        const { data } = await axios.get(`${base}/users/profile`, { headers: { Authorization: `Bearer ${user.token}` } });
        setProfile(data);
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  if (!user) return <p>Please login</p>;
  if (!profile) return <p>Loading...</p>;

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow">
      <h1 className="text-xl font-bold mb-4">Profile</h1>
      <p>Name: {profile.name}</p>
      <p>Email: {profile.email}</p>
    </div>
  );
}
