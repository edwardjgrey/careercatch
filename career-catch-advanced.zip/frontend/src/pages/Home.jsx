import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function Home() {
  const position = [51.505, -0.09]; // London default
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Career Catch</h1>
      <div style={{ height: '400px' }}>
        <MapContainer center={position} zoom={13} style={{ height: '100%' }}>
          <TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <Marker position={position}><Popup>Example location</Popup></Marker>
        </MapContainer>
      </div>
    </div>
  );
}
