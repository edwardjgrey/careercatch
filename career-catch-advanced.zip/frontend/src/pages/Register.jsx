import React, { useState } from 'react';
import axios from 'axios';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${import.meta.env.VITE_API_URL || ''}/api/auth/register`, form);
      alert('Registered. Please login.');
    } catch (err) { console.error(err); alert('Register failed'); }
  };
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Register</h2>
      <form onSubmit={submit} className="space-y-2">
        <input placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
        <input placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
        <button type="submit">Register</button>
      </form>
    </div>
  );
}
