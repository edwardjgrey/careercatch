import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function JobDetails() {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const base = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
        const { data } = await axios.get(`${base}/jobs/${id}`);
        setJob(data);
      } catch (e) {
        setMsg('Failed to load');
      }
      setLoading(false);
    })();
  }, [id]);

  const apply = async () => {
    const raw = localStorage.getItem('career_catch_user');
    if (!raw) { setMsg('Login to apply'); return; }
    const token = JSON.parse(raw).token;
    try {
      const base = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
      await axios.post(`${base}/jobs/${id}/apply`, {}, { headers: { Authorization: `Bearer ${token}` } });
      setMsg('Applied successfully');
    } catch (e) { setMsg('Apply failed'); }
  };

  if (loading) return <p>Loading...</p>;
  if (!job) return <p>Not found</p>;

  return (
    <div>
      <h1 className="text-2xl font-bold">{job.title}</h1>
      <p className="mb-2">{job.company} — {job.location}</p>
      <p className="mb-4 whitespace-pre-line">{job.description}</p>
      <button onClick={apply} className="bg-green-600 text-white px-4 py-2 rounded">Apply</button>
      {msg && <p className="mt-2">{msg}</p>}
    </div>
  );
}
