import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function CreateJob() {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const navigate = useNavigate();
  const raw = localStorage.getItem('career_catch_user');
  const user = raw ? JSON.parse(raw) : null;

  const submit = async (e) => {
    e.preventDefault();
    try {
      const base = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
      await axios.post(`${base}/jobs`, { title, company, location, description }, { headers: { Authorization: `Bearer ${user.token}` } });
      navigate('/');
    } catch (e) {
      console.error(e);
    }
  };

  if (!user) return <p>Please login</p>;

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded shadow">
      <h1 className="text-xl font-bold mb-4">Post a Job</h1>
      <form onSubmit={submit} className="space-y-3">
        <input value={title} onChange={e=>setTitle(e.target.value)} className="border p-2 rounded w-full" placeholder="Title" required />
        <input value={company} onChange={e=>setCompany(e.target.value)} className="border p-2 rounded w-full" placeholder="Company" required />
        <input value={location} onChange={e=>setLocation(e.target.value)} className="border p-2 rounded w-full" placeholder="Location" required />
        <textarea value={description} onChange={e=>setDescription(e.target.value)} className="border p-2 rounded w-full" placeholder="Description" rows="6" required />
        <button className="bg-blue-600 text-white px-4 py-2 rounded w-full">Post Job</button>
      </form>
    </div>
  );
}
