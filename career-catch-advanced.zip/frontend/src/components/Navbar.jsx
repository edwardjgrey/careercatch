import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  const raw = localStorage.getItem('career_catch_user');
  const user = raw ? JSON.parse(raw) : null;
  return (
    <nav className="bg-white shadow mb-6">
      <div className="container mx-auto p-4 flex justify-between items-center">
        <Link to="/" className="text-xl font-bold">Career Catch</Link>
        <div className="space-x-4">
          {user ? (
            <>
              <Link to="/profile">{user.user.name}</Link>
              {user.user.isRecruiter && <Link to="/post-job">Post Job</Link>}
              <button onClick={()=>{localStorage.removeItem('career_catch_user'); window.location.href='/';}} className="bg-red-600 text-white px-3 py-1 rounded">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
