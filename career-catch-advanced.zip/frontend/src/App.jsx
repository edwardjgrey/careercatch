import React, { createContext, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import AppliedJobs from './pages/AppliedJobs';
import EmployerDashboard from './pages/EmployerDashboard';
import Alerts from './pages/Alerts';
import Assessments from './pages/Assessments';
import CompanyProfile from './pages/CompanyProfile';
import axios from 'axios';

export const AuthContext = createContext();

export default function AppWrapper() {
  const [user, setUser] = useState(null);

  // basic login helper to store token and fetch user
  const login = async (email, password) => {
    const res = await axios.post(`${import.meta.env.VITE_API_URL || ''}/api/auth/login`, { email, password });
    if (res.data && res.data.token) {
      localStorage.setItem('token', res.data.token);
      axios.defaults.headers.common['Authorization'] = 'Bearer ' + res.data.token;
      setUser(res.data.user);
    }
  };

  return (
    <AuthContext.Provider value={{ user, setUser, login }}>
      <BrowserRouter>
        <nav className="p-4 bg-gray-100 flex gap-4">
          <Link to="/">Home</Link>
          <Link to="/alerts">Alerts</Link>
          <Link to="/assessments">Assessments</Link>
          <Link to="/applied">Applied</Link>
          <Link to="/profile">Profile</Link>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile" element={<Profile userId={user ? user.id : null} />} />
          <Route path="/applied" element={<AppliedJobs userId={user ? user.id : null} />} />
          <Route path="/employer" element={<EmployerDashboard />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/assessments" element={<Assessments />} />
          <Route path="/company/:name" element={<CompanyProfile />} />
        </Routes>
      </BrowserRouter>
    </AuthContext.Provider>
  );
}
