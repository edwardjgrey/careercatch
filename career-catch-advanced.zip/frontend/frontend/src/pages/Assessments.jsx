import React from 'react';
export default function Assessments() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Skill Assessments</h2>
      <p>Take quick tests to demonstrate your skills. (Scaffold)</p>
    </div>
  );
}
