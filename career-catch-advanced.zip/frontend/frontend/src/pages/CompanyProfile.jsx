import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Chart } from 'react-chartjs-2';

export default function CompanyProfile({ companyName }) {
  const [reviews, setReviews] = useState([]);
  useEffect(()=>{
    if(!companyName) return;
    axios.get(`${import.meta.env.VITE_API_URL || ''}/api/reviews/company/${companyName}`)
      .then(r=>setReviews(r.data.reviews || []))
      .catch(e=>console.error(e));
  },[companyName]);
  const avg = reviews.length ? (reviews.reduce((s,r)=>s+r.rating,0)/reviews.length).toFixed(2) : 'N/A';
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">{companyName}</h2>
      <div>Average rating: {avg}</div>
      <div className="mt-4">Reviews:</div>
      {reviews.map((rev,i)=>(<div key={i} className="border p-2 my-2"><div>Rating: {rev.rating}</div><div>{rev.text}</div></div>))}
    </div>
  );
}
