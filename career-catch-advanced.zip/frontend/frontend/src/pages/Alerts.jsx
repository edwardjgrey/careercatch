import React, { useState } from 'react';
import axios from 'axios';

export default function Alerts() {
  const [form, setForm] = useState({ email: '', keyword: '', location: '' });
  const submit = async (e) => {
    e.preventDefault();
    await axios.post(`${import.meta.env.VITE_API_URL || ''}/api/alerts/subscribe`, form);
    alert('Subscribed to alerts (scaffold)');
  };
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Job Alerts</h2>
      <form onSubmit={submit} className="space-y-2">
        <input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="Email" />
        <input value={form.keyword} onChange={e=>setForm({...form,keyword:e.target.value})} placeholder="Keyword" />
        <input value={form.location} onChange={e=>setForm({...form,location:e.target.value})} placeholder="Location" />
        <button type="submit">Subscribe</button>
      </form>
    </div>
  );
}
