import React from 'react';

export default function EmployerDashboard() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Employer Dashboard</h2>
      <p>Tools for employers: verify, update application statuses, feature profile, upload branding assets.</p>
    </div>
  );
}
