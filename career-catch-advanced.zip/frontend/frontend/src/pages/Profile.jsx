import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function Profile({ userId }) {
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ skills: '', experience: '', education: '' });

  useEffect(()=>{
    if(!userId) return;
    axios.get(`${import.meta.env.VITE_API_URL || ''}/api/users/${userId}`).then(r=>{ setUser(r.data); setForm({ skills: (r.data.skills||[]).join(','), experience: r.data.experience||'', education: r.data.education||'' }) }).catch(console.error);
  },[userId]);

  const save = async () => {
    const payload = { userId, skills: form.skills, experience: form.experience, education: form.education };
    await axios.post(`${import.meta.env.VITE_API_URL || ''}/api/users/update-profile`, payload);
    alert('Profile updated (scaffold)');
  };

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Profile</h2>
      {user && <div>
        <div>Name: {user.name}</div>
        <div>Email: {user.email}</div>
      </div>}
      <div className="mt-4">
        <label>Skills (comma separated)</label>
        <input value={form.skills} onChange={e=>setForm({...form,skills:e.target.value})} />
        <label>Experience</label>
        <textarea value={form.experience} onChange={e=>setForm({...form,experience:e.target.value})} />
        <label>Education</label>
        <input value={form.education} onChange={e=>setForm({...form,education:e.target.value})} />
        <button onClick={save}>Save</button>
      </div>
    </div>
  );
}
