import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AppliedJobs({ userId }) {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    if (!userId) return;
    axios.get(`${import.meta.env.VITE_API_URL || ''}/api/applications/my-applications/${userId}`)
      .then(res => setApplications(res.data))
      .catch(err => console.error(err));
  }, [userId]);

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Applied Jobs</h2>
      {applications.map(a => (
        <div key={a.jobId} className="border p-3 mb-3 rounded">
          <h3 className="font-semibold">{a.title} — {a.company}</h3>
          {a.applications.map(app => (
            <div key={app._id} className="text-sm">
              <div>Applied: {new Date(app.appliedAt).toLocaleDateString()}</div>
              <div>Status: {app.status}</div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
