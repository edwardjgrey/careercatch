Career Catch — Full-stack Starter
--------------------------------
This archive contains a Node/Express backend and a Vite+React frontend for "Career Catch".

Quick start (Linux):

1) Backend
   cd backend
   npm install
   cp .env.example .env
   # edit .env to set MONGO_URI and JWT_SECRET
   npm run seed
   npm run dev

2) Frontend (in another terminal)
   cd frontend
   npm install
   export VITE_API_URL=http://localhost:5000/api
   npm run dev


## Enhanced Features Added (scaffold)
- Employer verification endpoints and upload handling (backend/routes/verify.js)
- Extended User and Job schemas (backend/models)
- Alerts, Assessments, Reviews, Applications management routes
- Frontend scaffold pages: AppliedJobs, EmployerDashboard, Alerts, Assessments, CompanyProfile, Profile

## Notes
This is a scaffolded enhancement: core endpoints and data models are present, but production concerns (authentication checks, input validation, secure file storage, email templates, Stripe secret management) must be completed before deployment.


## Advanced Enhancements Applied
- JWT auth, role-based middleware, express-validator input checks
- Nodemailer transporter util with SMTP support
- Stripe checkout session endpoint scaffold
- Frontend routing with auth context and map integration
- Dockerfile and docker-compose scaffold for local deployment

## Security & Production Notes
- Set environment variables: MONGO_URI, JWT_SECRET, STRIPE_SECRET_KEY, SMTP_* and EMAIL_FROM
- Replace placeholder implementations (email templates, payment prices, webhook verification) before production.
