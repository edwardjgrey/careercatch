const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Job = require('./models/Job');

async function seed() {
  await connectDB();
  await User.deleteMany({});
  await Job.deleteMany({});
  const u1 = await User.create({ name: 'Alice Candidate', email: 'alice@example.com', password: 'password123', role: 'candidate' });
  const u2 = await User.create({ name: 'Acme HR', email: 'hr@acme.com', password: 'password123', role: 'employer', verified: true });
  await Job.create({ title: 'Frontend Engineer', company: 'Acme Corp', description: 'React developer', location: 'London', postedBy: u2._id });
  console.log('Seeded');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
