const express = require('express');
const asyncHandler = require('express-async-handler');
const protect = require('../middleware/auth');
const User = require('../models/User');
const router = express.Router();

router.get('/profile', protect, asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('-password');
  res.json(user);
}));

router.put('/profile', protect, asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) { res.status(404); throw new Error('User not found'); }
  user.name = req.body.name || user.name;
  user.email = req.body.email || user.email;
  if (req.body.password) user.password = req.body.password;
  await user.save();
  res.json({ id: user._id, name: user.name, email: user.email, isRecruiter: user.isRecruiter });
}));

module.exports = router;

// Update profile endpoint (including profilePic upload via base64 or URL)
const multer = require('multer');
const upload = multer({ dest: 'uploads/profile-pics/' });

router.post('/update-profile', upload.single('profilePic'), async (req, res) => {
  try {
    const { userId, skills, experience, education, publicUrl } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ msg: 'User not found' });
    if (skills) user.skills = Array.isArray(skills) ? skills : skills.split(',').map(s=>s.trim());
    if (experience) user.experience = experience;
    if (education) user.education = education;
    if (publicUrl) user.publicUrl = publicUrl;
    if (req.file) user.profilePic = req.file.path;
    await user.save();
    res.json({ msg: 'Profile updated', user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

