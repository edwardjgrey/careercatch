const { protect, employer, admin } = require('../middleware/auth');
const express = require('express');
const router = express.Router();
const Job = require('../models/Job');
const User = require('../models/User');
const { createTransporter } = require('../config/mailer');

// Candidate applies for a job
router.post('/apply', protect, async (req, res) => {
  try {
    const { jobId, userId, resume, coverLetter } = req.body;
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ msg: 'Job not found' });
    job.applications.push({ user: userId, resume, coverLetter });
    await job.save();
    res.json({ msg: 'Applied' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Employer updates application status
router.post('/update-status', employer, async (req, res) => {
  try {
    const { jobId, applicationId, status } = req.body;
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ msg: 'Job not found' });
    const app = job.applications.id(applicationId);
    if (!app) return res.status(404).json({ msg: 'Application not found' });
    app.status = status;
    await job.save();

    // TODO: send email to candidate using nodemailer (placeholder)
    res.json({ msg: 'Status updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Get my applications (for candidate)
router.get('/my-applications/:userId', protect, async (req, res) => {
  try {
    const { userId } = req.params;
    const jobs = await Job.find({ 'applications.user': userId });
    // filter applications per job for the user
    const results = jobs.map(j => {
      const userApps = j.applications.filter(a => a.user.toString() === userId.toString());
      return { jobId: j._id, title: j.title, company: j.company, applications: userApps };
    });
    res.json(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
