const { protect, employer, admin } = require('../middleware/auth');
const express = require('express');
const router = express.Router();
const multer = require('multer');
const User = require('../models/User');

const upload = multer({ dest: 'uploads/verification/' });

// Employer submits verification docs
router.post('/', protect, upload.single('document'), async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ msg: 'User not found' });
    // store path to doc and mark pending review
    if (req.file) user.verificationDocs.push(req.file.path);
    user.verified = false;
    await user.save();
    return res.json({ msg: 'Verification submitted, pending review' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Admin can approve
router.post('/approve', admin, async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ msg: 'User not found' });
    user.verified = true;
    await user.save();
    res.json({ msg: 'User verified' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
