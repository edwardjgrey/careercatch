const { protect, employer, admin } = require('../middleware/auth');
const express = require('express');
const router = express.Router();
// Placeholder Stripe integration endpoints (server-side requires stripe secret in env)
router.post('/create-session', protect, employer, async (req, res) => {
  try {
  const Stripe = require('stripe');
  const stripe = Stripe(process.env.STRIPE_SECRET_KEY || '');
  const { priceId, successUrl, cancelUrl } = req.body;
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'payment',
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: successUrl || (req.headers.origin + '/payments/success'),
    cancel_url: cancelUrl || (req.headers.origin + '/payments/cancel')
  });
  res.json({ url: session.url, id: session.id });
} catch (err) {
  console.error('Stripe error', err);
  res.status(500).json({ msg: 'Payment error' });
}
});
module.exports = router;
