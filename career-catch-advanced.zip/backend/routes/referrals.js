const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/generate', async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ msg: 'User not found' });
    // referralCode exists on user by default; return it
    res.json({ referralCode: user.referralCode });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

router.post('/redeem', async (req, res) => {
  try {
    const { code, referredUserId } = req.body;
    const referrer = await User.findOne({ referralCode: code });
    if (!referrer) return res.status(404).json({ msg: 'Referral code not found' });
    referrer.referrals.push(referredUserId);
    await referrer.save();
    res.json({ msg: 'Referral recorded' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
