const express = require('express');
const router = express.Router();
const Job = require('../models/Job');

router.post('/:jobId', async (req, res) => {
  try {
    const { jobId } = req.params;
    const { userId, rating, text } = req.body;
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ msg: 'Job not found' });
    job.reviews.push({ user: userId, rating, text });
    await job.save();
    res.json({ msg: 'Review added' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

router.get('/company/:companyName', async (req, res) => {
  try {
    const { companyName } = req.params;
    const jobs = await Job.find({ company: companyName });
    const reviews = jobs.flatMap(j => j.reviews || []);
    res.json({ company: companyName, reviews });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
