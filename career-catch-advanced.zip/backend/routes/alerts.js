const express = require('express');
const router = express.Router();
const Alert = require('../models/Alert');
const nodeCron = require('node-cron');
const nodemailer = require('nodemailer');

// Subscribe endpoint
router.post('/subscribe', async (req, res) => {
  try {
    const { email, keyword, location, jobType } = req.body;
    const a = new Alert({ email, keyword, location, jobType });
    await a.save();
    res.json({ msg: 'Subscribed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// Simple cron job scaffold - in production move to worker
// Sends a daily digest (placeholder)
const transporter = nodemailer.createTransport({ sendmail: true });

nodeCron.schedule('0 8 * * *', async () => {
  try {
    const alerts = await Alert.find({ active: true });
    // For each alert, you would run a search and email matches. This is a placeholder scaffold.
    console.log('Running scheduled alert job for', alerts.length, 'alerts');
  } catch (err) {
    console.error('Alert cron error', err);
  }
});

module.exports = router;
