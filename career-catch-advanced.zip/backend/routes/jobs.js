const express = require('express');
const asyncHandler = require('express-async-handler');
const Job = require('../models/Job');
const protect = require('../middleware/auth');
const router = express.Router();

router.get('/', asyncHandler(async (req, res) => {
  const pageSize = 10;
  const page = Number(req.query.pageNumber) || 1;
  const keyword = req.query.keyword ? { title: { $regex: req.query.keyword, $options: 'i' } } : {};
  const location = req.query.location ? { location: { $regex: req.query.location, $options: 'i' } } : {};
  const filter = { ...keyword, ...location };
  const count = await Job.countDocuments(filter);
  const jobs = await Job.find(filter).populate('postedBy', 'name email').limit(pageSize).skip(pageSize * (page - 1)).sort({ createdAt: -1 });
  res.json({ jobs, page, pages: Math.ceil(count / pageSize) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate('postedBy', 'name email');
  if (!job) { res.status(404); throw new Error('Job not found'); }
  res.json(job);
}));

router.post('/', protect, asyncHandler(async (req, res) => {
  if (!req.user.isRecruiter) { res.status(403); throw new Error('Only recruiters can post jobs'); }
  const { title, company, location, description, salary, featured } = req.body;
  const job = new Job({ title, company, location, description, salary, postedBy: req.user._id, featured: !!featured });
  await job.save();
  res.status(201).json(job);
}));

router.post('/:id/apply', protect, asyncHandler(async (req, res) => {
  if (req.user.isRecruiter) { res.status(403); throw new Error('Recruiters cannot apply'); }
  const job = await Job.findById(req.params.id);
  if (!job) { res.status(404); throw new Error('Job not found'); }
  if (job.applicants.includes(req.user._id)) { res.status(400); throw new Error('Already applied'); }
  job.applicants.push(req.user._id);
  await job.save();
  res.json({ message: 'Applied' });
}));

module.exports = router;
