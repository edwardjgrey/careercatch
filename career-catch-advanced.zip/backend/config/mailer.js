const nodemailer = require('nodemailer');

function createTransporter() {
  // Use SMTP if configured, else fall back to sendmail
  if (process.env.SMTP_HOST && process.env.SMTP_USER) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT || 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
  }
  return nodemailer.createTransport({ sendmail: true });
}

module.exports = { createTransporter };
