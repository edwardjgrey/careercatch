const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.protect = async (req, res, next) => {
  let token = req.headers.authorization && req.headers.authorization.startsWith('Bearer') ? req.headers.authorization.split(' ')[1] : null;
  if (!token) return res.status(401).json({ msg: 'Not authorized, token missing' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = await User.findById(decoded.id).select('-password');
    next();
  } catch (err) {
    console.error(err);
    res.status(401).json({ msg: 'Not authorized, token failed' });
  }
};

exports.admin = (req, res, next) => {
  if (!req.user) return res.status(401).json({ msg: 'Not authorized' });
  if (req.user.role !== 'admin') return res.status(403).json({ msg: 'Admin access required' });
  next();
};

exports.employer = (req, res, next) => {
  if (!req.user) return res.status(401).json({ msg: 'Not authorized' });
  if (req.user.role !== 'employer' && req.user.role !== 'admin') return res.status(403).json({ msg: 'Employer access required' });
  next();
};
