const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
  email: { type: String, required: true },
  keyword: String,
  location: String,
  jobType: String,
  createdAt: { type: Date, default: Date.now },
  active: { type: Boolean, default: true }
});

module.exports = mongoose.model('Alert', alertSchema);
