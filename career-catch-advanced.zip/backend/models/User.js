const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const assessmentSchema = new mongoose.Schema({
  skill: String,
  score: Number,
  takenAt: { type: Date, default: Date.now }
});

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['candidate','employer','admin'], default: 'candidate' },
  verified: { type: Boolean, default: false },
  verificationDocs: [String],
  skills: [String],
  experience: String,
  education: String,
  profilePic: String,
  publicUrl: String,
  referralCode: { type: String, default: function(){ return uuidv4().split('-')[0]; } },
  referrals: [{ type: String }],
  premium: { type: Boolean, default: false },
  assessments: [assessmentSchema],
  createdAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

userSchema.methods.matchPassword = async function(enteredPassword) {
  const bcrypt = require('bcryptjs');
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
