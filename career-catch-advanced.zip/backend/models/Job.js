const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  resume: String,
  coverLetter: String,
  status: { type: String, enum: ['Pending','Interview Scheduled','Rejected','Hired'], default: 'Pending' },
  appliedAt: { type: Date, default: Date.now }
});

const reviewSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  rating: { type: Number, min: 1, max: 5 },
  text: String,
  createdAt: { type: Date, default: Date.now }
});

const jobSchema = new mongoose.Schema({
  title: String,
  company: String,
  companyId: mongoose.Schema.Types.ObjectId,
  description: String,
  location: String,
  coordinates: { lat: Number, lng: Number },
  type: String,
  salary: String,
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  applications: [applicationSchema],
  reviews: [reviewSchema],
  logoPath: String,
  videoPath: String,
  featured: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Job', jobSchema);
